sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("MonthlyEvent.controller.viewMonthlyEvent", {

		onDisplayAttend: function(oEvent) {
			var sSelectd;

			sSelectd = this.getView().byId("cmbMonthlyEvent").getSelectedItem().getKey();

			alert(sSelectd);
			// Now Get the Router Info

					// Now Get the Router Info
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
 
			 oRouter.navTo("attendlist");

			alert("OK");
			//this.getRouter().navTo("attendlist", {id: sSelectd});

		}

	});
});